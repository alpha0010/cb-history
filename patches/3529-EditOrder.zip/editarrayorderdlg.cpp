/*
 * This file is part of the Code::Blocks IDE and licensed under the GNU Lesser General Public License, version 3
 * http://www.gnu.org/licenses/lgpl-3.0.html
 *
 * $Revision: 7608 $
 * $Id: editarrayorderdlg.cpp 7608 2011-11-25 20:50:28Z mortenmacfly $
 * $HeadURL: svn://svn.code.sf.net/p/codeblocks/code/trunk/src/sdk/editarrayorderdlg.cpp $
 */

#include "sdk_precomp.h"

#ifndef CB_PRECOMP
    #include <wx/xrc/xmlres.h>
    #include <wx/intl.h>
    #include <wx/button.h>
    #include <wx/listbox.h>
    #include <wx/combobox.h>
    #include <wx/checkbox.h>
    #include <wx/stattext.h>
    #include <wx/regex.h>
    #include "configmanager.h"
#endif

#include "editarrayorderdlg.h" // class's header file

#define CONF_GROUP _T("/SortOrderDlg")

BEGIN_EVENT_TABLE(EditArrayOrderDlg, wxScrollingDialog)
    EVT_UPDATE_UI( -1, EditArrayOrderDlg::OnUpdateUI)
    EVT_TEXT_ENTER(XRCID("cmbFind"), EditArrayOrderDlg::OnFindAll)
    EVT_BUTTON(XRCID("btnFindAll"), EditArrayOrderDlg::OnFindAll)

    EVT_BUTTON(XRCID("btnMoveTop"), EditArrayOrderDlg::OnMoveTop)
    EVT_BUTTON(XRCID("btnMoveTopB"), EditArrayOrderDlg::OnMoveTop)
    EVT_BUTTON(XRCID("btnMoveUp"), EditArrayOrderDlg::OnMoveUp)
    EVT_BUTTON(XRCID("btnMoveUpB"), EditArrayOrderDlg::OnMoveUp)
    EVT_BUTTON(XRCID("btnMoveDown"), EditArrayOrderDlg::OnMoveDown)
    EVT_BUTTON(XRCID("btnMoveDownB"), EditArrayOrderDlg::OnMoveDown)
    EVT_BUTTON(XRCID("btnMoveBottom"), EditArrayOrderDlg::OnMoveBottom)
    EVT_BUTTON(XRCID("btnMoveBottomB"), EditArrayOrderDlg::OnMoveBottom)

    EVT_BUTTON(XRCID("btnCollapseTop"), EditArrayOrderDlg::OnCollapseTop)
    EVT_BUTTON(XRCID("btnCollapseBottom"), EditArrayOrderDlg::OnCollapseBottom)
    EVT_BUTTON(XRCID("btnSortAsc"), EditArrayOrderDlg::OnSortAsc)
    EVT_BUTTON(XRCID("btnSortDes"), EditArrayOrderDlg::OnSortDes)

    EVT_BUTTON(XRCID("btnSelAll"), EditArrayOrderDlg::OnSelAll)
    EVT_BUTTON(XRCID("btnSelAllB"), EditArrayOrderDlg::OnSelAll)
    EVT_BUTTON(XRCID("btnSelNone"), EditArrayOrderDlg::OnSelNone)
    EVT_BUTTON(XRCID("btnSelNoneB"), EditArrayOrderDlg::OnSelNone)

    EVT_CHECKBOX(XRCID("chkAdv"), EditArrayOrderDlg::OnAdvanced)
    EVT_BUTTON(XRCID("btnReset"), EditArrayOrderDlg::OnReset)

    EVT_LISTBOX(XRCID("lstItems"), EditArrayOrderDlg::OnListSelection)
END_EVENT_TABLE()

void EditArrayOrderDlg::SetDynamicEvents()
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);

    list->Connect(wxID_ANY, wxEVT_RIGHT_DOWN, wxMouseEventHandler(EditArrayOrderDlg::OnRightDown), NULL, this);
    list->Connect(wxID_ANY, wxEVT_RIGHT_UP, wxMouseEventHandler(EditArrayOrderDlg::OnRightUp), NULL, this);
}

// class constructor
EditArrayOrderDlg::EditArrayOrderDlg(wxWindow* parent, const wxArrayString& array)
    : m_Array(array)
{
    ConfigManager* cfg = Manager::Get()->GetConfigManager(_T("editor"));

    wxXmlResource::Get()->LoadObject(this, parent, _T("dlgEditArrayOrder"),_T("wxScrollingDialog"));
    LoadPreviousSettings();
    DoFillList();
    SetDynamicEvents();

    SetWinSize(wxSize(cfg->ReadInt(CONF_GROUP _T("/WindowSizeW"),-1),cfg->ReadInt(CONF_GROUP _T("/WindowSizeH"),-1)));
    this->Center();
}

// class destructor
EditArrayOrderDlg::~EditArrayOrderDlg()
{
    int w, h;
    wxArrayString values;

    wxComboBox* findbox = XRCCTRL(*this, "cmbFind", wxComboBox);

    for (int x = 0; (x < (int)findbox->GetCount()) && (x < 9); ++x)
    {
        if (!findbox->GetString(x).IsEmpty() && (values.Index(findbox->GetString(x)) == wxNOT_FOUND))
            values.Add(findbox->GetString(x));
    }
    wxString find = findbox->GetValue();
    int prev_pos = values.Index(find);
    if (prev_pos != wxNOT_FOUND)
        values.RemoveAt(prev_pos);
    values.Insert(find, 0);
    ConfigManager* cfg = Manager::Get()->GetConfigManager(_T("editor"));

    cfg->Write(CONF_GROUP _T("/Searches"), values);

    cfg->Write(CONF_GROUP _T("/FindCase"), XRCCTRL(*this, "chkFindCase", wxCheckBox)->GetValue());
    cfg->Write(CONF_GROUP _T("/RegEx"), XRCCTRL(*this, "chkRegEx", wxCheckBox)->GetValue());
    cfg->Write(CONF_GROUP _T("/SortCase"), XRCCTRL(*this, "chkSortCase", wxCheckBox)->GetValue());
    cfg->Write(CONF_GROUP _T("/FindMode"), XRCCTRL(*this, "FindMode", wxChoice)->GetCurrentSelection());

    cfg->Write(CONF_GROUP _T("/Advanced"), XRCCTRL(*this, "chkAdv", wxCheckBox)->GetValue());

    this->GetSize(&w,&h);
    cfg->Write(CONF_GROUP _T("/WindowSizeW"),w);
    cfg->Write(CONF_GROUP _T("/WindowSizeH"),h);
}

void EditArrayOrderDlg::OnRightDown(wxMouseEvent& event)
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    int item = list->HitTest(event.GetPosition());
    m_LastSelected = item;

    m_DraggedIntArray.Empty();
    m_DraggedStringArray.Empty();

    if(item != wxNOT_FOUND)
    {
        list->SetSelection(item);
        int IntArraySize = list->GetSelections(m_DraggedIntArray);
        for (int x = 0; x < IntArraySize; x++)
            m_DraggedStringArray.Add(list->GetString(m_DraggedIntArray[x]));
    }
    UpdateSelNum();
}

void EditArrayOrderDlg::OnRightUp(wxMouseEvent& event)
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);

    int IntArraySize = m_DraggedIntArray.GetCount();
    int item = list->HitTest(event.GetPosition());
    int offset;

    if(item != wxNOT_FOUND && item != m_LastSelected)
    {
        if(m_LastSelected > item)
        {
            offset = m_LastSelected - item;
            if(m_DraggedIntArray[0] - offset < 0)
                offset = m_DraggedIntArray[0];
            for (int x = 0; x < IntArraySize; x++)
            {
                list->Delete(m_DraggedIntArray[x]);
                wxString out;
                list->InsertItems(1, &m_DraggedStringArray[x], m_DraggedIntArray[x] - offset);
                list->SetSelection(m_DraggedIntArray[x] - offset);
            }
        }
        else
        {
            offset = item - m_LastSelected;
            if(m_DraggedIntArray[IntArraySize - 1] + offset > (int)list->GetCount() - 1)
                offset = ((int)list->GetCount() - 1) - m_DraggedIntArray[IntArraySize - 1];
            for (int x = IntArraySize - 1; x >= 0; x--)
            {
                list->Delete(m_DraggedIntArray[x]);
                list->InsertItems(1, &m_DraggedStringArray[x], m_DraggedIntArray[x] + offset);
                list->SetSelection(m_DraggedIntArray[x] + offset);
            }
        }
    }
    m_DraggedIntArray.Empty();
    m_DraggedStringArray.Empty();
}

void EditArrayOrderDlg::UpdateSelNum()
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxStaticText* numsel = XRCCTRL(*this, "NumSel", wxStaticText);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray);

    wxString numselstring;
    if (IntArraySize)
    {
        numselstring.Printf(_("Number of Selected: %i"), IntArraySize);
        numsel->SetLabel(numselstring);
    }
    else
    {
        numselstring = _("Number of Selected: 0");
        numsel->SetLabel(numselstring);
    }
}

void EditArrayOrderDlg::OnReset(wxCommandEvent& WXUNUSED(event))
{
    DoFillList();
    UpdateSelNum();
}

void EditArrayOrderDlg::DoFillList()
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);

    list->Clear();
    for (unsigned int i = 0; i < m_Array.GetCount(); ++i)
        list->Append(m_Array[i]);
}

void EditArrayOrderDlg::LoadPreviousSettings()
{
    wxComboBox* findbox = XRCCTRL(*this, "cmbFind", wxComboBox);
    wxCheckBox* casechk = XRCCTRL(*this, "chkFindCase", wxCheckBox);
    wxChoice* findmode = XRCCTRL(*this, "FindMode", wxChoice);
    wxCheckBox* regexchk = XRCCTRL(*this, "chkRegEx", wxCheckBox);
    wxCheckBox* scasechk = XRCCTRL(*this, "chkSortCase", wxCheckBox);
    wxCheckBox* advchk = XRCCTRL(*this, "chkAdv", wxCheckBox);

    ConfigManager* cfg = Manager::Get()->GetConfigManager(_T("editor"));

    int tmp;
    wxArrayString values;
    cfg->Read(CONF_GROUP _T("/Searches"), &values);
    for (unsigned int x = 0; x < values.GetCount(); ++x)
    {
        if (!values[x].IsEmpty())
            findbox->Append(values[x]);
    }
    casechk->SetValue(cfg->ReadBool(CONF_GROUP _T("/FindCase"), false));
    scasechk->SetValue(cfg->ReadBool(CONF_GROUP _T("/SortCase"), false));
    regexchk->SetValue(cfg->ReadBool(CONF_GROUP _T("/RegEx"), false));
    cfg->Read(CONF_GROUP _T("/FindMode"), &tmp);
    findmode->SetSelection(tmp);
    advchk->SetValue(cfg->ReadBool(CONF_GROUP _T("/Advanced"), false));
    DoAdvanced();
}

void EditArrayOrderDlg::OnUpdateUI(wxUpdateUIEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray);
    if (IntArraySize)
    {
        XRCCTRL(*this, "btnMoveTop", wxButton)->Enable(IntArray[0] > 0);
        XRCCTRL(*this, "btnMoveTopB", wxButton)->Enable(IntArray[0] > 0);
        XRCCTRL(*this, "btnMoveUp", wxButton)->Enable(IntArray[0] > 0);
        XRCCTRL(*this, "btnMoveUpB", wxButton)->Enable(IntArray[0] > 0);
        XRCCTRL(*this, "btnMoveDown", wxButton)->Enable(IntArray[IntArraySize - 1] >= 0 && IntArray[IntArraySize - 1] < (int)list->GetCount() - 1);
        XRCCTRL(*this, "btnMoveDownB", wxButton)->Enable(IntArray[IntArraySize - 1] >= 0 && IntArray[IntArraySize - 1] < (int)list->GetCount() - 1);
        XRCCTRL(*this, "btnMoveBottom", wxButton)->Enable(IntArray[IntArraySize - 1] >= 0 && IntArray[IntArraySize - 1] < (int)list->GetCount() - 1);
        XRCCTRL(*this, "btnMoveBottomB", wxButton)->Enable(IntArray[IntArraySize - 1] >= 0 && IntArray[IntArraySize - 1] < (int)list->GetCount() - 1);

        XRCCTRL(*this, "btnSortAsc", wxButton)->Enable(IntArraySize > 1);
        XRCCTRL(*this, "btnSortDes", wxButton)->Enable(IntArraySize > 1);
        XRCCTRL(*this, "chkSortCase", wxCheckBox)->Enable(IntArraySize > 1);

        XRCCTRL(*this, "btnCollapseTop", wxButton)->Enable(IntArraySize > 1);
        XRCCTRL(*this, "btnCollapseBottom", wxButton)->Enable(IntArraySize > 1);

        XRCCTRL(*this, "btnSelAll", wxButton)->Enable(IntArraySize < (int)list->GetCount());
        XRCCTRL(*this, "btnSelAllB", wxButton)->Enable(IntArraySize < (int)list->GetCount());
        XRCCTRL(*this, "btnSelNone", wxButton)->Enable(IntArraySize > 0);
        XRCCTRL(*this, "btnSelNoneB", wxButton)->Enable(IntArraySize > 0);
    }
    else
    {
        XRCCTRL(*this, "btnMoveTop", wxButton)->Enable(false);
        XRCCTRL(*this, "btnMoveTopB", wxButton)->Enable(false);
        XRCCTRL(*this, "btnMoveUp", wxButton)->Enable(false);
        XRCCTRL(*this, "btnMoveUpB", wxButton)->Enable(false);
        XRCCTRL(*this, "btnMoveDown", wxButton)->Enable(false);
        XRCCTRL(*this, "btnMoveDownB", wxButton)->Enable(false);
        XRCCTRL(*this, "btnMoveBottom", wxButton)->Enable(false);
        XRCCTRL(*this, "btnMoveBottomB", wxButton)->Enable(false);

        XRCCTRL(*this, "btnSortAsc", wxButton)->Enable(false);
        XRCCTRL(*this, "btnSortDes", wxButton)->Enable(false);
        XRCCTRL(*this, "chkSortCase", wxCheckBox)->Enable(false);

        XRCCTRL(*this, "btnCollapseTop", wxButton)->Enable(false);
        XRCCTRL(*this, "btnCollapseBottom", wxButton)->Enable(false);

        XRCCTRL(*this, "btnSelAll", wxButton)->Enable(true);
        XRCCTRL(*this, "btnSelAllB", wxButton)->Enable(true);
        XRCCTRL(*this, "btnSelNone", wxButton)->Enable(false);
        XRCCTRL(*this, "btnSelNoneB", wxButton)->Enable(false);
    }
}

void EditArrayOrderDlg::SetWinSize(wxSize s)
{
    wxSize mins(-1,-1);
    SetMinSize(mins);
    this->Layout();
    this->Fit();
    mins = this->GetSize();
    this->SetMinSize(mins);
    if(s.x >= mins.x and s.y >= mins.y)
    {
        this->SetSize(s);
    }
    this->Refresh();
}

void EditArrayOrderDlg::DoAdvanced()
{
    wxSize s = this->GetSize();

    if(XRCCTRL(*this, "chkAdv", wxCheckBox)->GetValue())
    {
        XRCCTRL(*this, "pnlBasic", wxPanel)->Show(false);
        XRCCTRL(*this, "pnlAdvanced", wxPanel)->Show(true);
        XRCCTRL(*this, "pnlFind", wxPanel)->Show(true);
    }
    else
    {
        XRCCTRL(*this, "pnlAdvanced", wxPanel)->Show(false);
        XRCCTRL(*this, "pnlFind", wxPanel)->Show(false);
        XRCCTRL(*this, "pnlBasic", wxPanel)->Show(true);
    }

    SetWinSize(s);
}

void EditArrayOrderDlg::OnAdvanced(wxCommandEvent& WXUNUSED(event))
{
    DoAdvanced();
}

void EditArrayOrderDlg::OnFindAll(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxComboBox* findbox = XRCCTRL(*this, "cmbFind", wxComboBox);
    wxCheckBox* casechk = XRCCTRL(*this, "chkFindCase", wxCheckBox);
    wxChoice* findmode = XRCCTRL(*this, "FindMode", wxChoice);
    wxCheckBox* regexchk = XRCCTRL(*this, "chkRegEx", wxCheckBox);
    int wxRegExFlags = 0;

    wxArrayString StrArray = list->GetStrings();
    wxString findtxt = findbox->GetValue();

    if(!findtxt.IsEmpty())
    {

        if(regexchk->GetValue())
        {
            #ifdef wxHAS_REGEX_ADVANCED
            if(Manager::Get()->GetConfigManager(_T("editor"))->ReadBool(_T("/use_advanced_regexes"), false))
                wxRegExFlags |= wxRE_ADVANCED;
            #endif
        }

        if(!casechk->GetValue())
        {
            findtxt.MakeLower();
            for (int x = 0; x < (int)StrArray.GetCount(); x++)
                StrArray[x].MakeLower();

            if(regexchk->GetValue())
            {
                wxRegExFlags |= wxRE_ICASE;
            }
        }

        if(findmode->GetCurrentSelection() == 0)
        {
            for (int x = 0; x < (int)list->GetCount(); x++)
                list->Deselect(x);
        }

        for (int x = 0; x < (int)StrArray.GetCount(); x++)
        {
            if(regexchk->GetValue())
            {
                wxRegEx RegExp;
                if(!RegExp.Compile(findtxt,wxRegExFlags))
                {
                    wxMessageBox(_("Syntax Error in Regular Expression"));
                    break;
                }
                else if(RegExp.Matches(StrArray[x],wxRegExFlags))
                {
                    if(findmode->GetCurrentSelection() == 2)
                        list->Deselect(x);
                    else
                        list->SetSelection(x);
                }
            }
            else
            {
                if(StrArray[x].Find(findtxt) != wxNOT_FOUND)
                {
                    if(findmode->GetCurrentSelection() == 2)
                        list->Deselect(x);
                    else
                        list->SetSelection(x);
                }
            }
        }
        UpdateSelNum();
    }
}

void EditArrayOrderDlg::OnMoveTop(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray);

    for (int x = 0; x < IntArraySize; x++)
    {
        if (IntArray[x] > 0)
        {
            wxString tmp = list->GetString(IntArray[x]);
            list->Delete(IntArray[x]);
            list->InsertItems(1, &tmp, IntArray[x] - IntArray[0]);
            list->SetSelection(IntArray[x] - IntArray[0]);
        }
    }
}

void EditArrayOrderDlg::OnMoveUp(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray);

    for (int x = 0; x < IntArraySize; x++)
    {
        if (IntArray[x] > 0)
        {
            wxString tmp = list->GetString(IntArray[x]);
            list->Delete(IntArray[x]);
            list->InsertItems(1, &tmp, IntArray[x] - 1);
            list->SetSelection(IntArray[x] - 1);
        }
    }
}

void EditArrayOrderDlg::OnMoveDown(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray) - 1;

    for (int x = IntArraySize; x >= 0; x--)
    {
        if (IntArray[x] < (int)list->GetCount() - 1)
        {
            wxString tmp = list->GetString(IntArray[x]);
            list->Delete(IntArray[x]);
            list->InsertItems(1, &tmp, IntArray[x] + 1);
            list->SetSelection(IntArray[x] + 1);
        }
    }
}

void EditArrayOrderDlg::OnMoveBottom(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray) - 1;

    for (int x = IntArraySize; x >= 0; x--)
    {
        if (IntArray[x] < (int)list->GetCount() - 1)
        {
            wxString tmp = list->GetString(IntArray[x]);
            list->Delete(IntArray[x]);
            list->InsertItems(1, &tmp, ((int)list->GetCount() - IntArray[IntArraySize]) + IntArray[x]);
            list->SetSelection(((int)list->GetCount() - 1 - IntArray[IntArraySize]) + IntArray[x]);
        }
    }
}

void EditArrayOrderDlg::OnCollapseTop(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray);

    int FirstPos = IntArray[0];
    for (int x = 1; x < IntArraySize; x++)
    {
            FirstPos++;
            wxString tmp = list->GetString(IntArray[x]);
            list->Delete(IntArray[x]);
            list->InsertItems(1, &tmp, FirstPos);
            list->SetSelection(FirstPos);
    }
}

void EditArrayOrderDlg::OnCollapseBottom(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray) - 1;

    int LastPos = IntArray[IntArraySize];
    for (int x = IntArraySize - 1; x >= 0; x--)
    {
            LastPos--;
            wxString tmp = list->GetString(IntArray[x]);
            list->Delete(IntArray[x]);
            list->InsertItems(1, &tmp, LastPos);
            list->SetSelection(LastPos);
    }
}

void EditArrayOrderDlg::OnSortAsc(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxCheckBox* casechk = XRCCTRL(*this, "chkSortCase", wxCheckBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray);
    wxArrayString StringArray;
    wxArrayString StringArrayTemp;
    wxArrayString StringArrayTemp2;
    wxString tmp;
    for (int x = 0; x < IntArraySize; x++)
    {
        tmp = list->GetString(IntArray[x]);
        StringArray.Add(tmp);
        StringArrayTemp2.Add(tmp);
        StringArrayTemp.Add(tmp.MakeLower());
    }

    if(casechk->GetValue())
        StringArray.Sort();
    else
    {
        StringArrayTemp.Sort();
        for (int x = 0; x < IntArraySize; x++)
        {
            for (int y = 0; y < IntArraySize; y++)
            {
                tmp = StringArrayTemp2[y];
                tmp.MakeLower();
                if(StringArrayTemp[x].Find(tmp) != wxNOT_FOUND && tmp.Len() == StringArrayTemp[x].Len())
                {
                    StringArray[x] = StringArrayTemp2[y];
                    StringArrayTemp[x].Clear();
                }
            }
        }
    }

    for (int x = 0; x < IntArraySize; x++)
    {
        list->Delete(IntArray[x]);
        list->InsertItems(1, &StringArray[x], IntArray[x]);
        list->SetSelection(IntArray[x]);
    }
}

void EditArrayOrderDlg::OnSortDes(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);
    wxCheckBox* casechk = XRCCTRL(*this, "chkSortCase", wxCheckBox);
    wxArrayInt IntArray;
    int IntArraySize = list->GetSelections(IntArray);
    wxArrayString StringArray;
    wxArrayString StringArrayTemp;
    wxArrayString StringArrayTemp2;
    wxString tmp;
    for (int x = 0; x < IntArraySize; x++)
    {
        tmp = list->GetString(IntArray[x]);
        StringArray.Add(tmp);
        StringArrayTemp2.Add(tmp);
        StringArrayTemp.Add(tmp.MakeLower());
    }

    if(casechk->GetValue())
    {
        StringArray.Sort(true);
    }
    else
    {
        StringArrayTemp.Sort(true);
        for (int x = 0; x < IntArraySize; x++)
        {
            for (int y = 0; y < IntArraySize; y++)
            {
                tmp = StringArrayTemp2[y];
                tmp.MakeLower();
                if(StringArrayTemp[x].Find(tmp) != wxNOT_FOUND && tmp.Len() == StringArrayTemp[x].Len())
                {
                    StringArray[x] = StringArrayTemp2[y];
                    StringArrayTemp[x].Clear();
                }
            }
        }
    }

    for (int x = 0; x < IntArraySize; x++)
    {
        list->Delete(IntArray[x]);
        list->InsertItems(1, &StringArray[x], IntArray[x]);
        list->SetSelection(IntArray[x]);
    }
}

void EditArrayOrderDlg::OnSelAll(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);

    for (int x = 0; x < (int)list->GetCount(); x++)
        list->SetSelection(x);
    UpdateSelNum();
}

void EditArrayOrderDlg::OnSelNone(wxCommandEvent& WXUNUSED(event))
{
    wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);

    for (int x = 0; x < (int)list->GetCount(); x++)
        list->Deselect(x);
    UpdateSelNum();
}

void EditArrayOrderDlg::OnListSelection(wxCommandEvent& WXUNUSED(event))
{
    UpdateSelNum();
}

void EditArrayOrderDlg::EndModal(int retCode)
{
    if (retCode == wxID_OK)
    {
        wxListBox* list = XRCCTRL(*this, "lstItems", wxListBox);

        m_Array.Clear();
        for (int i = 0; i < (int)list->GetCount(); ++i)
            m_Array.Add(list->GetString(i));
    }

    wxScrollingDialog::EndModal(retCode);
}
