/*
 * This file is part of the Code::Blocks IDE and licensed under the GNU Lesser General Public License, version 3
 * http://www.gnu.org/licenses/lgpl-3.0.html
 */

#ifndef EDITARRAYORDERDLG_H
#define EDITARRAYORDERDLG_H

#include "scrollingdialog.h"
#include <wx/arrstr.h>
#include "settings.h"

/*
 * No description
 */
class EditArrayOrderDlg : public wxScrollingDialog
{
	public:
		// class constructor
		EditArrayOrderDlg(wxWindow* parent, const wxArrayString& array);
		// class destructor
		~EditArrayOrderDlg();
		EditArrayOrderDlg& operator=(const EditArrayOrderDlg&){ return *this; } // just to satisfy script bindings (never used)
		void SetArray(const wxArrayString& array){ m_Array = array; }
		const wxArrayString& GetArray(){ return m_Array; }
		void EndModal(int retCode);
		void OnFindAll(wxCommandEvent& event);
		void OnMoveTop(wxCommandEvent& event);
		void OnMoveUp(wxCommandEvent& event);
		void OnMoveDown(wxCommandEvent& event);
		void OnMoveBottom(wxCommandEvent& event);
		void OnCollapseTop(wxCommandEvent& event);
		void OnCollapseBottom(wxCommandEvent& event);
		void OnSortAsc(wxCommandEvent& event);
		void OnSortDes(wxCommandEvent& event);
		void OnSelAll(wxCommandEvent& event);
		void OnSelNone(wxCommandEvent& event);
		void OnListSelection(wxCommandEvent& event);
		void OnUpdateUI(wxUpdateUIEvent& event);
		void OnRightUp(wxMouseEvent& event);
		void OnRightDown(wxMouseEvent& event);
		void OnAdvanced(wxCommandEvent& event);
		void OnReset(wxCommandEvent& event);

    private:
        void SetDynamicEvents();
        void DoFillList();
        void SetWinSize(wxSize);
        void DoAdvanced();
		void UpdateSelNum();
		void LoadPreviousSettings();
        wxArrayString m_Array;
        wxArrayString m_DraggedStringArray;
        wxArrayInt m_DraggedIntArray;
        int m_LastSelected;
        //wxMenu srchmenu;
    	DECLARE_EVENT_TABLE()
};

#endif // EDITARRAYORDERDLG_H

